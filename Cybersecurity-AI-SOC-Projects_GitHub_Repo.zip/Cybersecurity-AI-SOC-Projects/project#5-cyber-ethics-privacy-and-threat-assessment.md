# Project #5: Cyber Ethics, Privacy & Threat Assessment

## Overview

This project presents a cybersecurity risk assessment focused on privacy, compliance, incident response, and data protection in a higher-education environment.

## Frameworks & Areas

- NIST SP 800-171
- GLBA
- SOPPA
- FTC Safeguards Rule
- Incident Response Planning
- Data Loss Prevention
- Security Awareness
- Executive Reporting

## What I Did

- Assessed privacy, security, and compliance risks in an academic environment.
- Identified gaps involving device encryption, breach response, and delayed notification processes.
- Recommended improvements to incident response roles, escalation paths, and communication workflows.
- Proposed SIEM, DLP, encryption, and third-party risk monitoring controls.
- Translated technical risks into executive-level recommendations.
- Supported risk reduction through practical security control improvements.

## Security Value

This project demonstrates GRC, compliance, audit support, executive communication, and risk-based cybersecurity thinking. It shows the ability to assess controls and communicate security priorities clearly.

## Recruiter Keywords

GRC, Risk Assessment, Compliance, NIST, GLBA, SOPPA, FTC Safeguards Rule, Incident Response Plan, Data Protection, DLP, Executive Reporting, Audit Support
