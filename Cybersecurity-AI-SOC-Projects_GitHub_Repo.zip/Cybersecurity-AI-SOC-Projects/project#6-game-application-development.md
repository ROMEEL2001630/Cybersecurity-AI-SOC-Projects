# Project #6: Game Application Development

## Overview

This project demonstrates software development experience through a game application built using JavaScript, C#, .NET, and Visual Studio Code. The project helped strengthen programming, debugging, backend logic, application design, and secure coding practices.

## Tools Used

- JavaScript
- C#
- .NET
- Visual Studio Code
- Version control
- Debugging and testing tools

## What I Did

- Developed core game application logic and user interaction features.
- Applied clean architecture principles to keep the application maintainable.
- Used secure coding practices to handle user input and reduce common application risks.
- Tested and debugged application behavior to improve reliability.
- Used version control practices to manage development changes.
- Connected computer science fundamentals with secure software development.

## Security Value

This project shows software engineering ability, which is valuable in cybersecurity roles that require understanding application behavior, secure development, DevSecOps, and technical troubleshooting.

## Recruiter Keywords

Game Application, JavaScript, C#, .NET, Secure Coding, Software Development, Debugging, Testing, Application Security, Clean Architecture, Computer Science
