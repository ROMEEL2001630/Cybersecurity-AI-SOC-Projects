# Cybersecurity AI SOC Projects

This repository contains a collection of cybersecurity projects focused on **SOC operations, SIEM log analysis, AWS cloud security, Python-based network monitoring, AI-assisted alert triage, secure coding, GRC, and security-focused software development**.

Each project provides a structured overview of the problem, tools used, investigation workflow, security value, and recruiter-focused skills demonstrated. The goal of this portfolio is to show practical, hands-on cybersecurity work across both **Computer Science** and **Cybersecurity**, including detection, analysis, automation, risk reduction, and secure development.

## Projects

**Network Monitoring & Analysis for AWS Cloud Security:** This project focuses on detecting suspicious network activity targeting AWS-hosted users and cloud resources. It uses Nmap, Wireshark, TShark, and Python libraries to identify suspicious IPs, enrich findings with geolocation details, and support IP-based blocking to help protect user data and cloud infrastructure.

**AI-Powered SOC Alert Triage Agent:** This project demonstrates an AI-assisted security workflow designed to support SOC analysts by analyzing alerts, reducing false positives, enriching indicators, mapping suspicious activity to MITRE ATT&CK, and recommending investigation or response actions.

**Splunk SIEM Log Analysis & Detection Tuning:** This project provides a structured approach to analyzing security logs in Splunk SIEM. It focuses on SPL searching, event correlation, alert triage, false positive reduction, IOC identification, detection tuning, dashboards, and SOC reporting.

**Secure Coding Guidelines for Python:** This project documents secure Python development practices to reduce common application security risks such as SQL injection, command injection, path traversal, insecure deserialization, unsafe file handling, and improper error disclosure.

**Cyber Ethics, Privacy & Threat Assessment:** This project presents an executive-level cybersecurity risk assessment focused on privacy, compliance, incident response, data protection, and control improvement using frameworks such as NIST, GLBA, SOPPA, and the FTC Safeguards Rule.

**Game Application Development:** This project demonstrates software development experience through a game application built using JavaScript, C#, .NET, and Visual Studio Code, with attention to clean architecture, input handling, testing, debugging, and secure coding practices.

**Blockchain & Smart Contract Security:** This project focuses on Ethereum blockchain development using Solidity, Web3.js, MetaMask, ERC-20 tokens, ERC-721 NFTs, Sepolia testnet deployment, smart contract testing, debugging, and gas optimization.

## Skills Demonstrated

- SOC alert triage and investigation
- SIEM monitoring and Splunk SPL analysis
- False positive reduction and detection tuning
- IOC enrichment and event correlation
- Threat hunting and MITRE ATT&CK mapping
- AWS cloud security monitoring
- Python automation for security analysis
- Network monitoring with Nmap, Wireshark, and TShark
- Vulnerability management and risk-based remediation
- IAM, MFA, access control, and least privilege
- Secure coding and DevSecOps practices
- GRC, compliance, audit support, and executive reporting
- AI-assisted and agentic cybersecurity workflows

## Tools & Technologies

**Security Tools:** Splunk, Microsoft Sentinel, Microsoft Defender, Nessus, Qualys, Wireshark, TShark, Nmap  
**Cloud & IAM:** AWS, Azure, IAM, MFA, least privilege, cloud logging, access control  
**Programming & Querying:** Python, Bash, PowerShell, SQL, SPL, KQL, JavaScript, C#, Solidity  
**Frameworks:** NIST CSF, NIST SP 800-53, NIST SP 800-171, ISO 27001, CIS Controls, HIPAA, PCI DSS  
**Security Areas:** SOC Operations, Incident Response, Threat Hunting, Cloud Security, GRC, Secure Coding, Vulnerability Management

## Professional Focus

I am focused on building practical cybersecurity skills that align with modern security teams, including AI-assisted SOC workflows, cloud security monitoring, detection engineering, secure development, and risk-based decision-making.

This portfolio reflects my ability to investigate security events, reduce noise, protect cloud environments, document findings, and communicate technical risks clearly to both technical and non-technical stakeholders.

## Disclaimer

All projects are created for educational, academic, and professional portfolio purposes. Any logs, indicators, datasets, or examples used are sanitized, simulated, or publicly available. No confidential, private, or unauthorized data is included.
