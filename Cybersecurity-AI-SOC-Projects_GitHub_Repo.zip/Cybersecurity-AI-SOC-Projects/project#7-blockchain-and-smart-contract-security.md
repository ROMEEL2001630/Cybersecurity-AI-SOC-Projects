# Project #7: Blockchain & Smart Contract Security

## Overview

This project focuses on blockchain and smart contract development using Ethereum technologies. It includes smart contract creation, token standards, NFT development, wallet integration, testnet deployment, and smart contract testing.

## Tools Used

- Solidity
- REMIX IDE
- Web3.js
- MetaMask
- Sepolia Testnet
- ERC-20 tokens
- ERC-721 NFTs

## What I Did

- Designed and deployed smart contracts using Solidity.
- Created ERC-20 tokens and ERC-721 NFTs.
- Integrated Web3.js and MetaMask for wallet-based interaction.
- Tested smart contracts on the Sepolia Ethereum testnet.
- Debugged contract behavior and reviewed gas efficiency.
- Applied secure blockchain development principles to reduce smart contract risk.

## Security Value

This project demonstrates awareness of decentralized application security, blockchain development lifecycle, wallet interaction, smart contract testing, and secure logic design.

## Recruiter Keywords

Blockchain Security, Solidity, Smart Contracts, Web3.js, MetaMask, Ethereum, ERC-20, ERC-721, NFT Development, Sepolia Testnet, dApp Security, Gas Optimization
