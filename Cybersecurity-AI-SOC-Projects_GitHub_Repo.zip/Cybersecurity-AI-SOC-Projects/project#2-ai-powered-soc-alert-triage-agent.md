# Project #2: AI-Powered SOC Alert Triage Agent

## Overview

This project demonstrates an AI-assisted cybersecurity workflow designed to support SOC analysts during alert triage. The goal is to reduce repetitive manual analysis, enrich alerts with useful context, reduce false positives, and help analysts prioritize alerts based on risk.

## Tools & Concepts

- Python
- AI-assisted analysis
- SOC alert triage
- MITRE ATT&CK mapping
- IOC enrichment
- Detection logic
- Incident response workflow

## What I Did

- Designed a workflow to ingest and review security event data.
- Classified alerts based on suspicious patterns and risk indicators.
- Added context to alerts to support faster investigation.
- Focused on reducing false positives through better alert enrichment and validation.
- Mapped suspicious behaviors to MITRE ATT&CK techniques where applicable.
- Suggested investigation and response actions for analyst review.
- Structured the project to reflect modern AI-assisted and agentic cybersecurity workflows.

## Security Value

This project aligns with how modern security teams are using AI to support SOC operations. It demonstrates practical thinking around alert triage, analyst efficiency, false positive reduction, threat context, and risk-based response.

## Recruiter Keywords

AI Security, Agentic Cybersecurity, SOC Analyst, Alert Triage, False Positive Reduction, Alert Enrichment, IOC Enrichment, MITRE ATT&CK, Threat Hunting, Detection Engineering, Incident Response, Security Automation
