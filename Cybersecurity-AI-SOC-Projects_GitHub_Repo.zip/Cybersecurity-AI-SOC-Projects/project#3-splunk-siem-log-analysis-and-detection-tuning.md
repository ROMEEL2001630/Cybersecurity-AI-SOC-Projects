# Project #3: Splunk SIEM Log Analysis & Detection Tuning

## Overview

This project focuses on analyzing security logs using Splunk SIEM. It demonstrates how to search, filter, correlate, and investigate events to identify suspicious activity, reduce alert noise, and improve security monitoring.

## Tools Used

- Splunk SIEM
- SPL queries
- Dashboards
- Security logs
- Alert triage workflow

## What I Did

- Uploaded and reviewed log data in Splunk.
- Created SPL searches to identify suspicious patterns and security events.
- Analyzed log activity for possible indicators of compromise.
- Correlated events across different fields to improve investigation quality.
- Tuned detections to reduce false positives and improve alert relevance.
- Organized findings into dashboard-ready metrics for SOC reporting.
- Documented investigation steps in a clear analyst-friendly format.

## Security Value

This project demonstrates SIEM monitoring, log analysis, alert triage, detection tuning, and SOC reporting skills. It is aligned with entry-level and junior cybersecurity analyst responsibilities where Splunk, alert review, and investigation documentation are important.

## Recruiter Keywords

Splunk, SIEM, SPL, Log Analysis, Alert Triage, Event Correlation, False Positive Reduction, Detection Tuning, IOC Identification, Dashboards, SOC Reporting, Security Monitoring
