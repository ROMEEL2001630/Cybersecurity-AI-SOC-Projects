# Project #1: Network Monitoring & Analysis for AWS Cloud Security

## Overview

This project focuses on detecting suspicious network activity targeting AWS-hosted users and cloud resources. The goal was to identify possible attacker behavior, analyze traffic patterns, enrich suspicious IPs with geolocation details, and support blocking actions to help protect AWS cloud environments and user data.

## Tools Used

- Python
- Nmap
- Wireshark
- TShark
- AWS Cloud
- IP geolocation libraries
- Packet capture and log analysis techniques

## What I Did

- Captured and analyzed network traffic using Wireshark and TShark.
- Used Nmap to scan and identify suspicious hosts and exposed services.
- Developed Python logic to parse traffic data and extract suspicious IP addresses.
- Enriched suspicious IPs with geolocation details to support investigation context.
- Identified unusual network behavior that could indicate unauthorized access attempts or data theft attempts.
- Supported IP-based blocking recommendations to reduce risk to AWS-hosted users and cloud resources.
- Documented findings in a security-focused format for incident response and remediation.

## Security Value

This project demonstrates practical experience in cloud security monitoring, network defense, IOC analysis, traffic investigation, and response support. It shows how security analysts can combine open-source tools and Python automation to improve visibility and protect cloud environments.

## Recruiter Keywords

AWS Security, Cloud Security, Network Monitoring, Python, Nmap, Wireshark, TShark, IOC Analysis, Threat Detection, Incident Response, Geolocation Enrichment, Data Protection, IP Blocking, Security Automation
